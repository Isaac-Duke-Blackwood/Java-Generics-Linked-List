/*
 * Name: Isaac Blackwood
 * Class: SE 3345.002
 * Date: 9/18/2020
 * Description:
 * 	This serves as a test driver for all of the functions in the GenLinkedList class.
 */
import static java.lang.System.out;

import java.util.LinkedList;
import java.util.List;

import genericLinkedList.GenLinkedList;
public class Main 
{

	public static void main(String[] args) 
	{
		out.println("Create a new empty GenLinkedList, list1");
		GenLinkedList<Integer> list1 = new GenLinkedList<>();
		out.println(list1);

		out.println("addEnd(1)");
		list1.addEnd(1);
		out.println(list1);

		out.println("addEnd(2)");
		list1.addEnd(2);
		out.println(list1);
		
		out.println("addFront(3)");
		list1.addFront(3);
		out.println(list1);
		
		out.println("Create a new empty GenLinkedList, list2");
		GenLinkedList<Integer> list2 = new GenLinkedList<>();
		out.println(list2);
		
		out.println("addFront(3)");
		list2.addFront(3);
		out.println(list2);
		
		out.println("set(1, 16) (an exception should be thrown)");
		try
		{
			list2.set(1, 16);
		}
		catch (Exception e) 
		{
			out.println(e);
		}
		out.println(list2);
		
		out.println("set(0, 16)");
		list2.set(0, 16);
		out.println(list2);

		out.println("list1 again");
		out.println("set(1,13)");
		list1.set(1, 13);
		out.println(list1);
		
		out.println("get(1)");
		out.println(list1.getNode(1).data());
		
		out.println("swap(1, 16) (an exception should be thrown)");
		try
		{
			list1.swap(1, 16);
		}
		catch (Exception e) 
		{
			out.println(e);
		}
		out.println(list2);
		
		out.println("swap(1,2)");
		list1.swap(1, 2);
		out.println(list1);
		
		out.println("swap(0,2)");
		list1.swap(0, 2);
		out.println(list1);
		
		out.println("swap(1,1)");
		list1.swap(1, 1);
		out.println(list1);
		
		out.println("removeFront()");
		list1.removeFront();
		out.println(list1);
		
		out.println("removeEnd()");
		list1.removeEnd();
		out.println(list1);
		
		out.println("add some values");
		list1.addEnd(23);
		list1.addEnd(16);
		list1.addEnd(54);
		list1.addEnd(23);
		list1.addEnd(74);
		list1.addEnd(75);
		list1.addEnd(32);
		list1.addEnd(16);
		out.println(list1);
		
		out.println("removeMatching(16)");
		list1.removeMatching(16);
		out.println(list1);
		
		out.println("erase(2,2)");
		list1.erase(2,2);
		out.println(list1);
		
		out.println("create new LinkedList, javaList");
		List<Integer> javaList = new LinkedList<>();
		javaList.add(1);
		javaList.add(2);
		javaList.add(3);
		javaList.add(4);
		out.println(javaList);
		
		out.println("insertList(javaList, 0)");
		list1.insertList(javaList, 0);
		out.println(list1);		
		
		out.println("insertList(javaList, 7)");
		list1.insertList(javaList, 7);
		out.println(list1);	
	}
}
