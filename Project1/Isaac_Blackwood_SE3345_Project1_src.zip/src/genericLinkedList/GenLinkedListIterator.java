package genericLinkedList;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class GenLinkedListIterator<T> implements Iterator<Node<T>>
{
	private Node<T> current;
	
	//Methods
	//Constructor
	public GenLinkedListIterator(GenLinkedList<T> genLinkedList) 
	{
		current = new Node<T>();
		current.next(genLinkedList.head());
	}

	@Override
	public boolean hasNext() 
	{
		return current.hasNext();
	}

	@Override
	public Node<T> next() 
	{
		if (null == current.next())
		{
			throw new NoSuchElementException();
		}
		current = current.next();
		return current;
	}
}
