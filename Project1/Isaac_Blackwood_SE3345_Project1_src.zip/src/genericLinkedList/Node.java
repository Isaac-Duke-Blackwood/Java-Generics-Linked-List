/*
 * Name: Isaac Blackwood
 * Class: SE 3345.002
 * Date: 9/18/2020
 * Description:
 * 	This is the data holding node for a linked list implementation that can hold any type using Java Generics.
 */
package genericLinkedList;

public class Node<T> 
{ 
	//Constants
	private static final String EMPTY_NODE = "[Empty Node]-->";
	
	//Data members
	private T data = null;
	private Node<T> next = null;
	
	//Methods
	//Constructors
	public Node() {}
	public Node(T data)
	{
		this.data = data(data);
	}
	public Node(T data, Node<T> next)
	{
		this.data = data(data);
		this.next = next(next);
	}
	public Node(Node<T> node) //copy constructor. NOTE: shallow copy behavior (copy data only)
	{
		this.data = node.data();
	}
	
	//Object
	@Override
	public String toString()
	{
		if (isEmpty())
		{
			return EMPTY_NODE;
		}
		return data.toString() + "-->";
	}
	@Override
	public boolean equals(Object o)
	{
		if (null == o)
		{
			return false;
		}
		else if (o instanceof Node<?>)
		{
			//cast o to Node
			Node<?> node = (Node<?>) o;
			if (node.data().equals(data))
			{
				//the data and types were the same
				return true;
			}
		}
		return false;
	}
	
	//Getters
	public T data()
	{
		return data;
	}
	
	public Node<T> next()
	{
		return next;
	}
	
	//Setters
	public T data(T data)
	{
		return this.data = data;
	}
	public Node<T> next(Node<T> next)
	{
		return this.next = next;
	}
	
	//isEmpty and hasNext()
	public boolean isEmpty()
	{
		if (null == data)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean hasNext()
	{
		if (null != next)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}
